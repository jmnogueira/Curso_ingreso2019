//Debemos lograr mostrar un mensaje al presionar el botón  'mostrar'.
function mostrar()
{
	var nombre;
	nombre=jose;
	nombre=prompt("jose");
	alert("jose"); 

}

