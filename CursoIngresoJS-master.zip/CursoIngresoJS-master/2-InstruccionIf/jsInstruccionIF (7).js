function mostrar()
{
//tomo la edad  

	


}//FIN DE LA FUNCIÓN